#!/bin/bash
set -u
resource_dir="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$resource_dir/install.sh"
result=$?
printf '\n'
if [ "$result" -ne 0 ]; then
  printf '操作未完成，退出码：%s。请保留上面的错误提示。\n' "$result"
fi
printf '按回车结束，随后可关闭本窗口。'
IFS= read -r ignored </dev/tty || true
exit "$result"
