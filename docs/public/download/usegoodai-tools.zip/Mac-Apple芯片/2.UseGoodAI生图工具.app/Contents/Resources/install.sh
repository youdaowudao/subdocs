#!/bin/bash
set -eu
resource_dir="$(cd "$(dirname "$0")" && pwd)"
exec "$resource_dir/tool" install
