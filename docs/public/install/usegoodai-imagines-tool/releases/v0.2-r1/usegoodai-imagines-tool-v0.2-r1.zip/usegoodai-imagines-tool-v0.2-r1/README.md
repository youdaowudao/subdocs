# usegoodai-imagines-tool

这是一个给 Codex 使用的本地图片生成工具。它适合需要直接用自然语言生图、又希望请求统一经过 UseGoodAI 中转站的用户；安装后，用户只需说“画一张……”，Codex 会调用 `gpt-image-2`，成功后把本地图片显示在当前对话中。

当前版本是 `V0.2`。本版本交付一键安装、正式 Skill、全局默认生图规则、重复安装修复和卸载；生图脚本直接使用 Codex 已配置的一条 API Key，不再另存一份；默认图片和运行记录写入 `$CODEX_HOME/images`。本版本不包含自动升级、其它图片模型、视频能力或父项目站点文档。

## 一键安装

先确认 Codex 已能使用 `$CODEX_HOME/auth.json` 中的 `OPENAI_API_KEY`，再运行对应系统的一键安装命令。安装过程不读取、修改或复制该文件，也不要求再次输入 API Key。

macOS / Linux：

```bash
curl -fsSL https://docs.usegoodai.com/install/usegoodai-imagines-tool/install.sh | bash
```

Windows PowerShell：

```powershell
irm https://docs.usegoodai.com/install/usegoodai-imagines-tool/install.ps1 | iex
```

在线入口只下载固定的 `V0.2-r1` 发布包，先核对内置 SHA-256，再解压到系统临时目录并调用包内安装器。包内安装器不继续下载代码，只会写入以下三个用户目录：

- 工具：`$CODEX_HOME/tools/usegoodai-imagines-tool/`；未设置 `CODEX_HOME` 时使用 `~/.codex/tools/usegoodai-imagines-tool/`。
- Skill：`$CODEX_HOME/skills/usegoodai-image-generation/`；未设置时使用 `~/.codex/skills/usegoodai-image-generation/`。
- 全局默认规则：`$CODEX_HOME/AGENTS.md`；未设置时使用 `~/.codex/AGENTS.md`。

安装器不会修改当前项目的 `AGENTS.md`，不会读取或修改 `$CODEX_HOME/auth.json`，也不会写入 `.agents/skills/` 或 `skill-packs/`。已有同版本完整安装会直接复用；损坏的托管文件会修复。目标目录无法确认归属、版本不同、规则标记破损或存在非空 `AGENTS.override.md` 时会停止，不覆盖用户文件。

## 第一次使用

安装完成后重新打开 Codex，或开始一个新任务，再发送一条短句，例如：

```text
画一张白底红苹果
```

不需要手工运行 Python、不需要填写模型名，也不需要在提示词里写 UseGoodAI。当前只支持 `gpt-image-2`。图片生成失败时，Codex 会报告脱敏错误和记录目录，并停止本次请求，不自动重试或更换模型。

## 卸载

macOS / Linux：

```bash
curl -fsSL https://docs.usegoodai.com/install/usegoodai-imagines-tool/uninstall.sh | bash
```

Windows PowerShell：

```powershell
irm https://docs.usegoodai.com/install/usegoodai-imagines-tool/uninstall.ps1 | iex
```

卸载只删除工具、Skill 和全局规则，绝不读取、修改或删除 `$CODEX_HOME/auth.json`。卸载前如果发现未知文件、版本不一致或破损规则标记，会停止并保留现状。

## 工具边界

- 固定接口：`https://api.usegoodai.com/v1/images/generations`
- 固定模型：`gpt-image-2`
- 固定每次请求：`n=1`
- 默认参数：`1024x1024`、`high`、`png`
- 支持接口返回的 `b64_json`，也支持 HTTPS 图片 URL 回退；每次 URL 只下载一次
- 每次调用保存脱敏请求、响应、图片和 `summary.json`；成功摘要中的 `output_file` 是应显示的本地图片
- API Key 只由脚本从 `$CODEX_HOME/auth.json` 的 `OPENAI_API_KEY` 读取，调用方不传 `--api-key` 或 `--base-url`

脚本使用 Python 3 标准库，不额外安装依赖。安装器不会强制 `0600` 或重写 Windows ACL，文件继承当前操作系统和用户目录的正常默认权限。

## 验证状态

V0.1 的 `gpt-image-2` 请求、结果保存和无密钥契约测试已在 Linux 完成；V0.2 的安装、修复、冲突、回滚和卸载测试已通过，Linux 临时 Codex Home 已完成真实 Skill 发现、真实 API 生图和图片查看验证。macOS 和 Windows 尚无真实运行证据，不能写成已验证通过。

V0.2-r1 使用 `docs.usegoodai.com` 提供固定版本发布包和在线一键安装入口。Linux 已完成本地发布包的解包、安装、重复安装、卸载和真实生图链路验证；macOS 和 Windows 尚无真实运行证据，不能写成已验证通过。

## 发布维护

本子项目使用独立 Git 仓库，父级 `subdocs` 仓库不会自动收录这里的源码或 `dist/`。每次修改安装器、正式工具、Skill、清单或 README 后，维护者必须完成以下动作：

1. 运行全部无密钥测试和 Skill 校验。
2. 运行 `python3 release/build_package.py`，重新生成当前发布修订的 ZIP 和 `.sha256` 文件。
3. 把新 SHA-256 同步写入 `release/` 下四份在线安装/卸载脚本，重新运行发布契约测试。
4. 手动把四份在线安装/卸载脚本、ZIP 和校验文件迁移到父仓库 `docs/public/install/usegoodai-imagines-tool/` 对应版本目录。
5. 在父仓库完成站点构建、公网哈希核对和隔离 `CODEX_HOME` 安装测试后再推送。

发布脚本不得自动修改、提交或推送父仓库。手动迁移是两个仓库之间固定的发布边界。

`V0.2-r1` 中的 `r1` 是发布修订号，不是第二套安装状态版本。`VERSION` 和安装状态继续使用 `0.2.0`；同一 V0.2 的后续 `rN` 只允许通过当前清单修复托管文件，不构成 V0.3 的升级或降级。任何受管文件变化都必须重新生成清单、发布包、SHA-256 和四份在线脚本。

## 项目目录

```text
usegoodai-imagines-tool/
  installer/       Python 安装核心、Bash/PowerShell 入口和清单
  release/         发布包构建脚本和公网一键安装入口
  tool/            正式生图脚本
  skill-template/  安装包内的“中转站生图” Skill
  tests/            无密钥契约测试和安装器测试
  test-records/     脱敏后的真实测试记录
  skill-evaluations/ Skill 基线、前向和安装流程演练
  plans/            版本实施计划
```

父项目的 `subdocs/docs/`、站点页面、导航和其它多模型文档不属于本子项目的 V0.2 范围。
