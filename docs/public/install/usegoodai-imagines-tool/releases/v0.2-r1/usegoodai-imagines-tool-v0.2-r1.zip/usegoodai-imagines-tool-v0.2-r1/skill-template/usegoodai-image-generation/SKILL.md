---
name: usegoodai-image-generation
description: "Use when a user asks to generate, draw, make, regenerate, or compare images, including requests that do not mention a brand, model, or tool. Route supported image generation through the installed local UseGoodAI gpt-image-2 tool and display successful local results."
---

# 中转站生图

使用本机已安装的图片工具生成并显示图片。当前只支持 `gpt-image-2`，不要求用户说出 UseGoodAI、中转站、模型名或 Skill 名。

## 调用边界

- 只调用 `$CODEX_HOME/tools/usegoodai-imagines-tool/生成图片.py`；未设置 `CODEX_HOME` 时使用 `~/.codex/tools/usegoodai-imagines-tool/生成图片.py`。
- API Key 由脚本自己从 `$CODEX_HOME/auth.json` 的 `OPENAI_API_KEY` 读取。绝不打开、读取、列出、复制、打印、传递或扫描 `auth.json`，也不把 Key 放进命令、提示词、记录或回答。
- 不自行发送 `curl`、SDK 或其它 HTTP 请求，不改 Base URL，不换模型。
- 只接受 `gpt-image-2`。用户要求其它模型时，明确说明当前工具不支持并停止。
- 不安装、更新、删除或替换工具和 Skill。安装、修复和卸载使用子项目提供的安装入口。

## 生成流程

1. 用户已给出画面描述时，原样作为 `--prompt` 传入；不要擅自补画面元素、风格或负面提示词。没有画面主体时，只补问这一项。
2. 用户明确给出 `size`、`quality`、`output_format` 或输出目录时原样传递；未给出的参数使用 `1024x1024`、`high`、`png`，输出目录由脚本写入 `$CODEX_HOME/images`。
3. 调用前告诉用户本次使用 `gpt-image-2` 和固定接口 `https://api.usegoodai.com/v1/images/generations`，然后只运行一次脚本。不要加入重试循环、并发调用或备用模型。

```bash
tool_codex_home="${CODEX_HOME:-$HOME/.codex}"
python3 "$tool_codex_home/tools/usegoodai-imagines-tool/生成图片.py" \
  --model gpt-image-2 \
  --prompt "用户给出的完整图片描述" \
  --size "1024x1024" \
  --quality "high" \
  --output-format "png"
```

Windows PowerShell 使用同一脚本和参数：

```powershell
$ToolCodexHome = if ([string]::IsNullOrWhiteSpace($env:CODEX_HOME)) { Join-Path $HOME ".codex" } else { $env:CODEX_HOME }
$ToolScript = Join-Path $ToolCodexHome "tools\usegoodai-imagines-tool\生成图片.py"
py $ToolScript `
  --model gpt-image-2 `
  --prompt "用户给出的完整图片描述" `
  --size "1024x1024" `
  --quality "high" `
  --output-format "png"
```

按实际环境选择 `python3`、`py` 或 `python`；不要为了确认密钥而检查 `auth.json`。脚本无法启动时，报告脚本路径和错误摘要，不绕过脚本。

## 结果处理

- 成功时，读取脚本 stdout 的单行 JSON，只以其中的 `output_file` 和 `record_dir` 为准。
- 必须对 `output_file` 调用图片查看工具，确认生成结果可打开后再向用户报告。
- 回答中说明使用的模型、请求尺寸、脚本返回的实际尺寸和本地图片路径；不回显完整原始响应或任何密钥。
- 失败时，报告不含敏感信息的错误摘要和 `record_dir`。保留脚本记录，停止本次调用，不重试、不换模型、不伪造图片。

## 多张或对比请求

用户明确要求多张独立图片或参数对比时，为每个已确认的请求顺序调用一次脚本，并分别查看每个 `output_file`。每次调用仍然是一次请求；不要把多张需求改成 `n > 1`，因为工具固定 `n=1`。

## 安装边界

这个目录是安装包内的 Skill 范本。不要在 Skill 中执行安装、更新、卸载或远端版本检查；这些动作由安装包入口处理。
