#!/usr/bin/env python3
"""Install or uninstall the V0.2 UseGoodAI image tool with Python stdlib only."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tempfile
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, TextIO


MANAGED_BY = "usegoodai-imagines-tool"
TOOL_NAME = "usegoodai-imagines-tool"
SKILL_NAME = "usegoodai-image-generation"
STATE_FILE_NAME = "install-manifest.json"
LEGACY_KEY_FILE_NAME = "api-key"
RULE_START = "<!-- usegoodai-image-generation:start -->"
RULE_END = "<!-- usegoodai-image-generation:end -->"
RULE_BLOCK = """<!-- usegoodai-image-generation:start -->
## 默认生图规则

- 用户要求生成、绘制或制作图片时，默认调用 `$usegoodai-image-generation`，不要求用户指定 UseGoodAI、中转站、Skill 名或模型名。
- Skill 只调用已安装的 `gpt-image-2` 生图工具；调用前说明本次模型和接口，不静默更换模型或接口。
- 把用户本次完整画面要求和明确参数传给工具，不使用写死的图片描述。
- 每张图片只发送一次请求；失败后保留记录并报告真实错误，不自动重试、不换模型。
- 成功后立即使用 `view_image` 打开脚本返回的本地 `output_file`，让图片显示在当前对话中，不能只回复路径或链接。
- API Key 由工具脚本直接从 `$CODEX_HOME/auth.json` 的 `OPENAI_API_KEY` 读取。AI 不打开、读取、复制、展示、记录、扫描或提交 `auth.json`。
<!-- usegoodai-image-generation:end -->"""

PACKAGE_FILES = {
    "VERSION",
    "tool/生成图片.py",
    f"skill-template/{SKILL_NAME}/SKILL.md",
    f"skill-template/{SKILL_NAME}/agents/openai.yaml",
}


class InstallationError(Exception):
    """A non-sensitive installation or uninstallation failure."""


@dataclass(frozen=True)
class InstallResult:
    status: str
    codex_home: Path
    tool_dir: Path
    skill_dir: Path
    agents_path: Path


@dataclass(frozen=True)
class Layout:
    codex_home: Path
    tool_dir: Path
    skill_dir: Path
    agents_path: Path
    override_path: Path
    state_path: Path


FailureHook = Callable[[str], None]


def resolve_codex_home(
    environ: Mapping[str, str] | None = None, home: Path | str | None = None
) -> Path:
    environment = os.environ if environ is None else environ
    configured = environment.get("CODEX_HOME", "").strip()
    if configured:
        return Path(configured).expanduser()
    fallback_home = Path.home() if home is None else Path(home)
    return fallback_home.expanduser() / ".codex"


def build_layout(codex_home: Path) -> Layout:
    tool_dir = codex_home / "tools" / TOOL_NAME
    return Layout(
        codex_home=codex_home,
        tool_dir=tool_dir,
        skill_dir=codex_home / "skills" / SKILL_NAME,
        agents_path=codex_home / "AGENTS.md",
        override_path=codex_home / "AGENTS.override.md",
        state_path=tool_dir / STATE_FILE_NAME,
    )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json_object(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise InstallationError(f"无法读取{label}：{path}") from error
    if not isinstance(value, dict):
        raise InstallationError(f"{label}格式无效：{path}")
    return value


def validate_package(source_root: Path) -> dict[str, Any]:
    source_root = source_root.resolve()
    manifest_path = source_root / "installer" / "manifest.json"
    manifest = _load_json_object(manifest_path, "安装清单")
    if manifest.get("schema_version") != 1 or manifest.get("managed_by") != MANAGED_BY:
        raise InstallationError("安装清单身份校验失败。")
    version = manifest.get("version")
    files = manifest.get("files")
    if not isinstance(version, str) or not version.strip() or not isinstance(files, dict):
        raise InstallationError("安装清单版本或文件列表无效。")
    if set(files) != PACKAGE_FILES:
        raise InstallationError("安装清单中的文件范围不正确。")
    version_path = source_root / "VERSION"
    try:
        package_version = version_path.read_text(encoding="utf-8").strip()
    except OSError as error:
        raise InstallationError(f"无法读取版本文件：{version_path}") from error
    if package_version != version:
        raise InstallationError("VERSION 与安装清单版本不一致。")
    for relative_path, expected_hash in files.items():
        if not isinstance(expected_hash, str) or len(expected_hash) != 64:
            raise InstallationError(f"安装清单哈希无效：{relative_path}")
        source_path = source_root / relative_path
        if source_path.is_symlink() or not source_path.is_file():
            raise InstallationError(f"安装包缺少普通文件：{relative_path}")
        if _sha256(source_path) != expected_hash:
            raise InstallationError(f"安装包文件校验失败：{relative_path}")
    return manifest


def _manifest_bytes(manifest: dict[str, Any]) -> bytes:
    return (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode(
        "utf-8"
    )


def _desired_files(
    source_root: Path, layout: Layout, manifest: dict[str, Any]
) -> dict[Path, bytes]:
    return {
        layout.tool_dir / "生成图片.py": (source_root / "tool" / "生成图片.py").read_bytes(),
        layout.tool_dir / "VERSION": (source_root / "VERSION").read_bytes(),
        layout.state_path: _manifest_bytes(manifest),
        layout.skill_dir / "SKILL.md": (
            source_root / "skill-template" / SKILL_NAME / "SKILL.md"
        ).read_bytes(),
        layout.skill_dir / "agents" / "openai.yaml": (
            source_root / "skill-template" / SKILL_NAME / "agents" / "openai.yaml"
        ).read_bytes(),
    }


def _ensure_directory_target(path: Path, label: str) -> None:
    if path.is_symlink() or (path.exists() and not path.is_dir()):
        raise InstallationError(f"{label}不是可管理的普通目录：{path}")


def _reject_symlink_components(base: Path, target: Path, label: str) -> None:
    try:
        relative_parts = target.relative_to(base).parts
    except ValueError as error:
        raise InstallationError(f"{label}不在 Codex Home 内：{target}") from error
    current = base
    for part in relative_parts:
        current /= part
        if current.is_symlink():
            raise InstallationError(f"{label}路径包含符号链接，停止操作：{current}")


def _check_managed_path_components(layout: Layout) -> None:
    for target, label in (
        (layout.tool_dir, "工具目录"),
        (layout.skill_dir, "Skill 目录"),
        (layout.skill_dir / "agents", "Skill 子目录"),
        (layout.agents_path, "AGENTS.md"),
        (layout.override_path, "AGENTS.override.md"),
    ):
        _reject_symlink_components(layout.codex_home, target, label)


def _read_installed_state(layout: Layout, manifest: dict[str, Any]) -> dict[str, Any] | None:
    _ensure_directory_target(layout.tool_dir, "工具目录")
    _ensure_directory_target(layout.skill_dir, "Skill 目录")
    if layout.state_path.is_symlink() or layout.state_path.exists():
        if layout.state_path.is_symlink() or not layout.state_path.is_file():
            raise InstallationError(f"安装状态文件不是普通文件：{layout.state_path}")
        state = _load_json_object(layout.state_path, "安装状态")
        if state.get("managed_by") != MANAGED_BY or state.get("schema_version") != 1:
            raise InstallationError(f"目标目录无法确认由本工具管理：{layout.tool_dir}")
        installed_version = state.get("version")
        if installed_version != manifest["version"]:
            raise InstallationError(
                f"已安装版本为 {installed_version}，当前安装包为 {manifest['version']}；V0.2 不执行升级或降级。"
            )
        return state

    if layout.tool_dir.is_symlink() or layout.tool_dir.exists():
        unknown = sorted(
            path.name for path in layout.tool_dir.iterdir() if path.name != LEGACY_KEY_FILE_NAME
        )
        if unknown:
            raise InstallationError(f"目标目录无法确认由本工具管理：{layout.tool_dir}")
    if layout.skill_dir.is_symlink():
        raise InstallationError(f"Skill 目录不是可管理的普通目录：{layout.skill_dir}")
    if layout.skill_dir.exists() and any(layout.skill_dir.iterdir()):
        raise InstallationError(f"目标目录无法确认由本工具管理：{layout.skill_dir}")
    return None


def _read_agents(layout: Layout, *, check_override: bool = True) -> str:
    if check_override and (layout.override_path.is_symlink() or layout.override_path.exists()):
        if layout.override_path.is_symlink() or not layout.override_path.is_file():
            raise InstallationError(f"AGENTS.override.md 不是普通文件：{layout.override_path}")
        try:
            override_is_nonempty = layout.override_path.stat().st_size > 0
        except OSError as error:
            raise InstallationError(f"无法检查 AGENTS.override.md：{layout.override_path}") from error
        if override_is_nonempty:
            raise InstallationError(
                f"发现非空 AGENTS.override.md，会覆盖同级 AGENTS.md：{layout.override_path}"
            )
    if layout.agents_path.is_symlink():
        raise InstallationError(f"AGENTS.md 不是普通文件：{layout.agents_path}")
    if not layout.agents_path.exists():
        return ""
    if not layout.agents_path.is_file():
        raise InstallationError(f"AGENTS.md 不是普通文件：{layout.agents_path}")
    try:
        content = layout.agents_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        raise InstallationError(f"无法读取 AGENTS.md：{layout.agents_path}") from error
    _marker_span(content)
    return content


def _marker_span(content: str) -> tuple[int, int] | None:
    start_count = content.count(RULE_START)
    end_count = content.count(RULE_END)
    if start_count == 0 and end_count == 0:
        return None
    if start_count != 1 or end_count != 1:
        raise InstallationError("AGENTS.md 中的中转站生图标记缺失、重复或不完整。")
    start = content.index(RULE_START)
    end = content.index(RULE_END)
    if end < start:
        raise InstallationError("AGENTS.md 中的中转站生图标记顺序错误。")
    return start, end + len(RULE_END)


def _install_rule(content: str) -> str:
    span = _marker_span(content)
    if span is not None:
        return content[: span[0]] + RULE_BLOCK + content[span[1] :]
    if not content:
        return RULE_BLOCK + "\n"
    separator = "\n\n" if content.endswith("\n") else "\n\n"
    return content.rstrip("\n") + separator + RULE_BLOCK + "\n"


def _remove_rule(content: str) -> str:
    span = _marker_span(content)
    if span is None:
        raise InstallationError("AGENTS.md 中缺少本工具规则块，停止卸载。")
    return content[: span[0]] + content[span[1] :]


def _same_file_bytes(path: Path, expected: bytes) -> bool:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise InstallationError(f"托管文件路径发生冲突：{path}")
    try:
        return path.is_file() and path.read_bytes() == expected
    except OSError as error:
        raise InstallationError(f"无法检查托管文件：{path}") from error


def _atomic_write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing_mode: int | None = None
    if path.is_symlink():
        raise InstallationError(f"文件路径发生冲突：{path}")
    if path.exists() and os.name != "nt":
        existing_mode = stat.S_IMODE(path.stat().st_mode)
    temporary_path = path.parent / f".usegoodai-tmp-{os.getpid()}-{uuid.uuid4().hex}"
    descriptor: int | None = None
    try:
        descriptor = os.open(temporary_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o666)
        with os.fdopen(descriptor, "wb") as handle:
            descriptor = None
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        if existing_mode is not None:
            os.chmod(temporary_path, existing_mode)
        os.replace(temporary_path, path)
    except Exception:
        if descriptor is not None:
            os.close(descriptor)
        try:
            temporary_path.unlink()
        except FileNotFoundError:
            pass
        raise


class _FileTransaction:
    def __init__(self) -> None:
        self._temporary = tempfile.TemporaryDirectory(prefix="usegoodai-install-")
        self._backup_root = Path(self._temporary.name)
        self._staging_root = self._backup_root / "staged"
        self._staging_root.mkdir()
        self._journal: list[tuple[Path, Path | None]] = []
        self._finished = False

    def stage(self, name: str, content: bytes) -> Path:
        staged_path = self._staging_root / name
        staged_path.parent.mkdir(parents=True, exist_ok=True)
        staged_path.write_bytes(content)
        return staged_path

    def write(self, path: Path, content: bytes) -> None:
        backup: Path | None = None
        if path.is_symlink() or path.exists():
            if not path.is_file():
                raise InstallationError(f"文件路径发生冲突：{path}")
            backup = self._backup_root / f"backup-{len(self._journal)}"
            shutil.copy2(path, backup)
        self._journal.append((path, backup))
        _atomic_write(path, content)

    def remove(self, path: Path) -> None:
        if not path.exists() and not path.is_symlink():
            return
        if path.is_symlink() or not path.is_file():
            raise InstallationError(f"文件路径发生冲突：{path}")
        backup = self._backup_root / f"backup-{len(self._journal)}"
        shutil.copy2(path, backup)
        self._journal.append((path, backup))
        path.unlink()

    def rollback(self) -> list[Path]:
        if self._finished:
            return []
        failures: list[Path] = []
        for path, backup in reversed(self._journal):
            try:
                if backup is None:
                    path.unlink(missing_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(backup, path)
            except OSError:
                failures.append(path)
        self._finished = True
        self._temporary.cleanup()
        return failures

    def commit(self) -> None:
        if self._finished:
            return
        self._finished = True
        self._temporary.cleanup()


def _backup_path(agents_path: Path) -> Path:
    timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
    return agents_path.with_name(f"AGENTS.md.usegoodai-backup-{timestamp}")


def _call_hook(failure_hook: FailureHook | None, stage: str) -> None:
    if failure_hook is not None:
        failure_hook(stage)


def _cleanup_empty_directories(layout: Layout) -> None:
    candidates = [
        layout.skill_dir / "agents",
        layout.skill_dir,
        layout.codex_home / "skills",
        layout.tool_dir,
        layout.codex_home / "tools",
    ]
    for path in candidates:
        try:
            path.rmdir()
        except OSError:
            pass


def install(
    *,
    source_root: Path | str,
    environ: Mapping[str, str] | None = None,
    home: Path | str | None = None,
    output: TextIO | None = None,
    failure_hook: FailureHook | None = None,
) -> InstallResult:
    destination_output = sys.stdout if output is None else output
    print("将安装图片工具、‘中转站生图’ Skill 和全局默认生图规则。", file=destination_output)
    print("工具运行时读取 Codex auth.json；安装器不会读取、修改或复制 API Key。", file=destination_output)

    root = Path(source_root).resolve()
    manifest = validate_package(root)
    layout = build_layout(resolve_codex_home(environ, home))
    _check_managed_path_components(layout)
    state = _read_installed_state(layout, manifest)
    agents_content = _read_agents(layout)
    desired_agents = _install_rule(agents_content)
    desired = _desired_files(root, layout, manifest)

    changed_files = [path for path, content in desired.items() if not _same_file_bytes(path, content)]
    agents_changed = desired_agents != agents_content
    if not changed_files and not agents_changed:
        print(f"V{manifest['version']} 已经完整安装，不需要重复写入。", file=destination_output)
        return InstallResult(
            "already-installed",
            layout.codex_home,
            layout.tool_dir,
            layout.skill_dir,
            layout.agents_path,
        )

    transaction = _FileTransaction()
    try:
        staged = {
            path: transaction.stage(str(index), content)
            for index, (path, content) in enumerate(desired.items())
        }
        for path in changed_files:
            transaction.write(path, staged[path].read_bytes())
        if agents_changed:
            if layout.agents_path.exists():
                transaction.write(_backup_path(layout.agents_path), agents_content.encode("utf-8"))
            transaction.write(layout.agents_path, desired_agents.encode("utf-8"))
        _call_hook(failure_hook, "managed-files-written")
        for path, content in desired.items():
            if not _same_file_bytes(path, content):
                raise InstallationError(f"安装后校验失败：{path}")
        if layout.agents_path.read_text(encoding="utf-8") != desired_agents:
            raise InstallationError(f"全局规则写入后校验失败：{layout.agents_path}")
        _call_hook(failure_hook, "validated")
    except Exception as error:
        rollback_failures = transaction.rollback()
        _cleanup_empty_directories(layout)
        if rollback_failures:
            failed_paths = "、".join(str(path) for path in rollback_failures)
            raise InstallationError(f"{error}；回滚不完整，请检查：{failed_paths}") from error
        if isinstance(error, InstallationError):
            raise
        raise InstallationError(f"本地文件操作失败：{error}") from error
    transaction.commit()

    if state is None:
        status = "installed"
    elif changed_files or agents_changed:
        status = "repaired"
    print(f"安装完成：V{manifest['version']}", file=destination_output)
    print(f"工具：{layout.tool_dir}", file=destination_output)
    print(f"Skill：{layout.skill_dir}", file=destination_output)
    print(f"全局规则：{layout.agents_path}", file=destination_output)
    print("请重新打开 Codex 或开始一个新任务，然后直接说：画一张白底红苹果。", file=destination_output)
    return InstallResult(
        status,
        layout.codex_home,
        layout.tool_dir,
        layout.skill_dir,
        layout.agents_path,
    )


def _assert_known_uninstall_files(layout: Layout) -> None:
    allowed_tool_files = {"生成图片.py", "VERSION", STATE_FILE_NAME, LEGACY_KEY_FILE_NAME}
    if layout.tool_dir.exists():
        for path in layout.tool_dir.iterdir():
            if path.is_symlink() or not path.is_file() or path.name not in allowed_tool_files:
                raise InstallationError(f"工具目录包含未知文件，停止卸载：{path}")
    allowed_skill_files = {Path("SKILL.md"), Path("agents/openai.yaml")}
    if layout.skill_dir.exists():
        for path in layout.skill_dir.rglob("*"):
            if path.is_symlink():
                raise InstallationError(f"Skill 目录包含未知文件，停止卸载：{path}")
            if path.is_file() and path.relative_to(layout.skill_dir) not in allowed_skill_files:
                raise InstallationError(f"Skill 目录包含未知文件，停止卸载：{path}")
            if path.is_dir() and path.relative_to(layout.skill_dir) != Path("agents"):
                raise InstallationError(f"Skill 目录包含未知目录，停止卸载：{path}")


def uninstall(
    *,
    source_root: Path | str,
    environ: Mapping[str, str] | None = None,
    home: Path | str | None = None,
    output: TextIO | None = None,
    failure_hook: FailureHook | None = None,
) -> InstallResult:
    destination_output = sys.stdout if output is None else output
    print("将卸载图片工具、‘中转站生图’ Skill 和全局默认生图规则。", file=destination_output)
    print("卸载不会读取、修改或删除 Codex auth.json。", file=destination_output)

    root = Path(source_root).resolve()
    manifest = validate_package(root)
    layout = build_layout(resolve_codex_home(environ, home))
    _check_managed_path_components(layout)
    state = _read_installed_state(layout, manifest)
    if state is None:
        agents_content = ""
        if layout.agents_path.exists():
            agents_content = _read_agents(layout, check_override=False)
            if _marker_span(agents_content) is not None:
                raise InstallationError("发现规则块但缺少安装状态，无法确认卸载范围。")
        status = "already-uninstalled"
        print("未发现可确认的 V0.2 安装，无需卸载。", file=destination_output)
        return InstallResult(
            status,
            layout.codex_home,
            layout.tool_dir,
            layout.skill_dir,
            layout.agents_path,
        )

    _assert_known_uninstall_files(layout)
    agents_content = _read_agents(layout, check_override=False)
    desired_agents = _remove_rule(agents_content)
    transaction = _FileTransaction()
    try:
        if layout.agents_path.exists():
            transaction.write(_backup_path(layout.agents_path), agents_content.encode("utf-8"))
            transaction.write(layout.agents_path, desired_agents.encode("utf-8"))
        _call_hook(failure_hook, "rule-removed")
        for path in (
            layout.skill_dir / "agents" / "openai.yaml",
            layout.skill_dir / "SKILL.md",
            layout.tool_dir / "生成图片.py",
            layout.tool_dir / "VERSION",
            layout.state_path,
        ):
            transaction.remove(path)
        _call_hook(failure_hook, "managed-files-removed")
    except Exception as error:
        rollback_failures = transaction.rollback()
        if rollback_failures:
            failed_paths = "、".join(str(path) for path in rollback_failures)
            raise InstallationError(f"{error}；回滚不完整，请检查：{failed_paths}") from error
        if isinstance(error, InstallationError):
            raise
        raise InstallationError(f"本地文件操作失败：{error}") from error
    transaction.commit()
    _cleanup_empty_directories(layout)

    status = "uninstalled"
    print("卸载完成。", file=destination_output)
    return InstallResult(
        status,
        layout.codex_home,
        layout.tool_dir,
        layout.skill_dir,
        layout.agents_path,
    )


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="安装或卸载 UseGoodAI 图片工具 V0.2。")
    subparsers = parser.add_subparsers(dest="command", required=True)
    install_parser = subparsers.add_parser("install", help="安装或修复 V0.2。")
    install_parser.add_argument(
        "--source-root",
        default=str(Path(__file__).resolve().parents[1]),
        help=argparse.SUPPRESS,
    )
    uninstall_parser = subparsers.add_parser("uninstall", help="卸载 V0.2。")
    uninstall_parser.add_argument(
        "--source-root",
        default=str(Path(__file__).resolve().parents[1]),
        help=argparse.SUPPRESS,
    )
    return parser


def main(
    argv: list[str] | None = None,
    *,
    environ: Mapping[str, str] | None = None,
) -> int:
    arguments = create_parser().parse_args(argv)
    action = "安装" if arguments.command == "install" else "卸载"
    try:
        if arguments.command == "install":
            install(
                source_root=arguments.source_root,
                environ=environ,
            )
        else:
            uninstall(
                source_root=arguments.source_root,
                environ=environ,
            )
    except InstallationError as error:
        print(f"{action}失败：{error}", file=sys.stderr)
        print("本次操作未完成；写入前已停止或已恢复本次修改。", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
